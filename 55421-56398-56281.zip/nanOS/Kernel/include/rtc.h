#ifndef RTC_H
#define RTC_H

unsigned int seconds();
unsigned int minutes();
unsigned int hour();

#endif
