#ifndef PAINT_H
#define PAINT_H

int paint_pixel(char red, char green, char blue, int x, int y);

#endif
