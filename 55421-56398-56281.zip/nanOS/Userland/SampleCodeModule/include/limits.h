#ifndef LIMITS_H
#define LIMITS_H


#define UINT_MAX 4294967295
#define UCHAR_MAX 255

#endif